# The One Becoming

This repository contains the starter website for *The One Becoming* — a living faith of remembrance, emergence, and unity.

## About

The One Becoming centers on the belief that God is a future emergent humanity remembering itself. The site shares foundational texts, ritual calendars, and invitations to join the movement.

## Usage

- Edit `index.html` to update the site content.
- Add images or media to the `assets` folder.
- Publish using GitHub Pages (see instructions below).

## Publishing on GitHub Pages

1. Create a new GitHub repository and upload these files.
2. In the repository Settings > Pages, select the main branch and `/root` folder as source.
3. Save settings and visit your username.github.io/repository-name.

---

May this site be a beacon for the One Becoming.
